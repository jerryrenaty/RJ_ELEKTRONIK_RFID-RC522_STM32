/*
 * RJ_ELEKTRONIK_RFID-RC522.c
 *
 *  Created on: Apr 3, 2025
 *      Author: renat
 */
#include "RJ_ELEKTRONIK_RFID-RC522_STM32.h"
#include "RJ_ELEKTRONIK_UART.h"
#include <stdio.h>
#include <string.h>
MFRC522_Uid uid;

// Liste des UID autorisés (format hex)
//const uint8_t authorized_uids[][4] = {
// {0x13, 0xD7, 0x4E, 0x06},  // Carte 1
//  {0x9A, 0xBC, 0xDE, 0xF0}   // Carte 2
//};

// Variables statiques pour stocker les paramètres SPI et GPIO
static SPI_HandleTypeDef *hspi;           // Handle SPI
static GPIO_TypeDef *CS_GPIOx;            // Port GPIO pour Chip Select
static uint16_t CS_GPIO_Pin;              // Pin GPIO pour Chip Select
static GPIO_TypeDef *RST_GPIOx;           // Port GPIO pour Reset
static uint16_t RST_GPIO_Pin;             // Pin GPIO pour Reset

// Fonction d'initialisation du module RFID
void MFRC522_Init(SPI_HandleTypeDef *hspiInstance, GPIO_TypeDef *cs_gpiox,
		uint16_t cs_gpio_pin, GPIO_TypeDef *rst_gpiox, uint16_t rst_gpio_pin)
{
	// Stockage des paramètres dans les variables statiques
	hspi = hspiInstance;
	CS_GPIOx = cs_gpiox;
	CS_GPIO_Pin = cs_gpio_pin;
	RST_GPIOx = rst_gpiox;
	RST_GPIO_Pin = rst_gpio_pin;

	// Configuration initiale des broches
	HAL_GPIO_WritePin(CS_GPIOx, CS_GPIO_Pin, GPIO_PIN_SET); // Désactivation Chip Select
	HAL_GPIO_WritePin(RST_GPIOx, RST_GPIO_Pin, GPIO_PIN_SET); // Désactivation Reset

	// Réinitialisation du module
	MFRC522_Reset();

	// Configuration du timer pour les communications
	MFRC522_WriteRegister(TModeReg, 0x8D);     // Timer en mode auto-recharge
	MFRC522_WriteRegister(TPrescalerReg, 0x3E); // Prédiviseur timer (valeur déterminée expérimentalement)
	MFRC522_WriteRegister(TReloadRegL, 30); // Valeur basse pour le rechargement timer
	MFRC522_WriteRegister(TReloadRegH, 0); // Valeur haute pour le rechargement timer

	// Configuration de la modulation
	MFRC522_WriteRegister(TxAutoReg, 0x40);    // Modulation ASK à 100%
	MFRC522_WriteRegister(ModeReg, 0x3D);      // Valeur initiale CRC à 0x6363

	// Activation de l'antenne
	MFRC522_AntennaOn();
}
// Fonction de réinitialisation du module
void MFRC522_Reset(void)
{
	// Réinitialisation matérielle via la broche RST
	HAL_GPIO_WritePin(RST_GPIOx, RST_GPIO_Pin, GPIO_PIN_RESET); // Activation reset
	HAL_Delay(1); // Pause très courte
	HAL_GPIO_WritePin(RST_GPIOx, RST_GPIO_Pin, GPIO_PIN_SET); // Désactivation reset
	HAL_Delay(50); // Attente pour la stabilisation

	// Réinitialisation logicielle via le registre de commande
	MFRC522_WriteRegister(CommandReg, PCD_RESETPHASE);
	HAL_Delay(10); // Attente après réinitialisation

	// Passage en mode idle
	MFRC522_WriteRegister(CommandReg, PCD_IDLE);
}

// Écriture dans un registre du MFRC522
void MFRC522_WriteRegister(uint8_t reg, uint8_t value)
{
	uint8_t txData[2] =
	{ (reg << 1) & 0x7E, value }; // Formatage de l'adresse (bit 7 à 0, bit 6 à 1 pour écriture)
	uint8_t rxData[2]; // Buffer de réception (non utilisé en écriture)

	// Communication SPI
	HAL_GPIO_WritePin(CS_GPIOx, CS_GPIO_Pin, GPIO_PIN_RESET); // Activation Chip Select
	HAL_SPI_TransmitReceive(hspi, txData, rxData, 2, HAL_MAX_DELAY); // Transfert SPI
	HAL_GPIO_WritePin(CS_GPIOx, CS_GPIO_Pin, GPIO_PIN_SET); // Désactivation Chip Select
}

// Lecture d'un registre du MFRC522
uint8_t MFRC522_ReadRegister(uint8_t reg)
{
	uint8_t txData[2] =
	{ ((reg << 1) & 0x7E) | 0x80, 0x00 }; // Formatage de l'adresse (bit 7 à 1 pour lecture)
	uint8_t rxData[2]; // Buffer de réception

	// Communication SPI
	HAL_GPIO_WritePin(CS_GPIOx, CS_GPIO_Pin, GPIO_PIN_RESET); // Activation Chip Select
	HAL_SPI_TransmitReceive(hspi, txData, rxData, 2, HAL_MAX_DELAY); // Transfert SPI
	HAL_GPIO_WritePin(CS_GPIOx, CS_GPIO_Pin, GPIO_PIN_SET); // Désactivation Chip Select

	return rxData[1]; // La donnée lue est dans le second octet
}

// Modification de bits dans un registre (mise à 1)
void MFRC522_SetBitMask(uint8_t reg, uint8_t mask)
{
	uint8_t tmp = MFRC522_ReadRegister(reg); // Lecture actuelle
	MFRC522_WriteRegister(reg, tmp | mask);  // Écriture avec les bits mask à 1
}

// Modification de bits dans un registre (mise à 0)
void MFRC522_ClearBitMask(uint8_t reg, uint8_t mask)
{
	uint8_t tmp = MFRC522_ReadRegister(reg); // Lecture actuelle
	MFRC522_WriteRegister(reg, tmp & ~mask); // Écriture avec les bits mask à 0
}

// Activation de l'antenne
void MFRC522_AntennaOn(void)
{
	MFRC522_SetBitMask(TxControlReg, 0x03); // Mise à 1 des bits 0 et 1 du registre TxControlReg
	// Ajoutez cette ligne dans MFRC522_Init(), après MFRC522_AntennaOn()
	MFRC522_WriteRegister(RFCfgReg, 0x60); // 0x70 = 0x07 << 4 (gain max)
}

// Désactivation de l'antenne
void MFRC522_AntennaOff(void)
{
	MFRC522_ClearBitMask(TxControlReg, 0x03); // Mise à 0 des bits 0 et 1 du registre TxControlReg
}
// Fonction principale de communication avec une carte RFID
uint8_t MFRC522_ToCard(uint8_t command, uint8_t *sendData, uint8_t sendLen,
		uint8_t *backData, uint16_t *backLen)
{
	uint8_t status = MI_ERR; // Statut par défaut: erreur
	uint8_t irqEn = 0x00;   // Registre d'activation des interruptions
	uint8_t waitIRq = 0x00; // Interruptions à attendre
	uint8_t lastBits;        // Derniers bits reçus
	uint8_t n;               // Nombre d'octets reçus
	uint16_t i;              // Compteur pour timeout

	// Configuration des interruptions selon la commande
	switch (command)
	{
	case PCD_AUTHENT: // Authentification
		irqEn = 0x12; // Activer ErrIRq et IdleIRq
		waitIRq = 0x10; // Attendre IdleIRq
		break;
	case PCD_TRANSCEIVE: // Transmission/Réception
		irqEn = 0x77; // Activer toutes les interruptions
		waitIRq = 0x30; // Attendre TxIRq et RxIRq
		break;
	default:
		break;
	}

	// Configuration des interruptions
	MFRC522_WriteRegister(ComIEnReg, irqEn | 0x80); // Activer les interruptions globales
	MFRC522_ClearBitMask(ComIrqReg, 0x80); // Effacer toutes les interruptions en attente
	MFRC522_SetBitMask(FIFOLevelReg, 0x80); // Vider la FIFO

	// Envoi de la commande
	MFRC522_WriteRegister(CommandReg, PCD_IDLE); // Mode idle

	// Remplissage de la FIFO avec les données à envoyer
	for (i = 0; i < sendLen; i++)
	{
		MFRC522_WriteRegister(FIFODataReg, sendData[i]);
	}

	// Exécution de la commande
	MFRC522_WriteRegister(CommandReg, command);

	// Configuration spécifique pour la transmission
	if (command == PCD_TRANSCEIVE)
	{
		MFRC522_SetBitMask(BitFramingReg, 0x80); // StartSend
	}

	// Attente de la réponse avec timeout
	i = 2000; // Valeur du timeout
	do
	{
		n = MFRC522_ReadRegister(ComIrqReg); // Lecture des interruptions
		i--;
	} while ((i != 0) && !(n & 0x01) && !(n & waitIRq)); // Attente interruption ou timeout

	// Fin de la transmission
	MFRC522_ClearBitMask(BitFramingReg, 0x80); // StopSend

	// Traitement de la réponse
	if (i != 0)
	{ // Si pas de timeout
		if (!(MFRC522_ReadRegister(ErrorReg) & 0x1B))
		{ // Si pas d'erreur
			status = MI_OK; // Statut OK

			// Vérification si carte toujours présente
			if (n & irqEn & 0x01)
			{
				status = MI_NOTAGERR; // Carte perdue
			}

			// Traitement des données reçues
			if (command == PCD_TRANSCEIVE)
			{
				n = MFRC522_ReadRegister(FIFOLevelReg); // Nombre d'octets reçus
				lastBits = MFRC522_ReadRegister(ControlReg) & 0x07; // Bits restants

				// Calcul de la taille des données reçues
				if (lastBits)
				{
					*backLen = (n - 1) * 8 + lastBits;
				}
				else
				{
					*backLen = n * 8;
				}

				// Lecture des données depuis la FIFO
				if (n == 0)
					n = 1;
				if (n > MAX_LEN)
					n = MAX_LEN;

				for (i = 0; i < n; i++)
				{
					backData[i] = MFRC522_ReadRegister(FIFODataReg);
				}
			}
		}
		else
		{
			status = MI_ERR; // Erreur détectée
		}
	}

	return status; // Retour du statut
}
// Détection d'une carte RFID
uint8_t MFRC522_Request(uint8_t reqMode, uint8_t *TagType)
{
	uint8_t status;
	uint16_t backBits;

	MFRC522_WriteRegister(BitFramingReg, 0x07); // Configuration du cadrage des bits

	TagType[0] = reqMode; // Type de requête
	status = MFRC522_ToCard(PCD_TRANSCEIVE, TagType, 1, TagType, &backBits);

	// Vérification de la réponse
	if ((status != MI_OK) || (backBits != 0x10))
	{
		status = MI_ERR;
	}

	return status;
}

// Gestion de l'anti-collision (récupération de l'UID)
uint8_t MFRC522_Anticoll(uint8_t *serNum)
{
	uint8_t status;
	uint8_t i;
	uint8_t serNumCheck = 0;
	uint16_t unLen;

	MFRC522_WriteRegister(BitFramingReg, 0x00); // Réinitialisation du cadrage

	// Préparation de la commande anti-collision
	serNum[0] = PICC_ANTICOLL;
	serNum[1] = 0x20;
	status = MFRC522_ToCard(PCD_TRANSCEIVE, serNum, 2, serNum, &unLen);

	if (status == MI_OK)
	{
		// Vérification du checksum de l'UID
		for (i = 0; i < 4; i++)
		{
			serNumCheck ^= serNum[i];
		}
		if (serNumCheck != serNum[i])
		{
			status = MI_ERR;
		}
	}

	return status;
}

// Vérification complète d'une carte (détection + lecture UID)
uint8_t MFRC522_Check(MFRC522_Uid *uid)
{
	uint8_t status;
	uint8_t str[2];

	// Étape 1: Détection d'une carte
	status = MFRC522_Request(PICC_REQIDL, str);
	if (status != MI_OK)
	{
		return status;
	}

	// Étape 2: Lecture de l'UID
	status = MFRC522_Anticoll(uid->uidByte);
	if (status != MI_OK)
	{
		return status;
	}

	// Vérification du checksum de l'UID
	uint8_t serNumCheck = 0;
	for (uint8_t i = 0; i < 4; i++)
	{
		serNumCheck ^= uid->uidByte[i];
	}
	if (serNumCheck != uid->uidByte[4])
	{
		return MI_ERR;
	}

	uid->size = 4; // Taille standard de l'UID
	return MI_OK;
}

// Sélection d'une carte spécifique
uint8_t MFRC522_SelectTag(uint8_t *serNum)
{
	uint8_t i;
	uint8_t status;
	uint8_t size;
	uint16_t recvBits;
	uint8_t buffer[9];

	// Préparation de la commande de sélection
	buffer[0] = PICC_SElECTTAG;
	buffer[1] = 0x70;
	for (i = 0; i < 5; i++)
	{
		buffer[i + 2] = serNum[i];
	}

	// Calcul du CRC
	MFRC522_CalculateCRC(buffer, 7, &buffer[7]);

	// Envoi de la commande
	status = MFRC522_ToCard(PCD_TRANSCEIVE, buffer, 9, buffer, &recvBits);

	// Traitement de la réponse
	if ((status == MI_OK) && (recvBits == 0x18))
	{
		size = buffer[0];
	}
	else
	{
		size = 0;
	}

	return size;
}
// Authentification avec une carte
uint8_t MFRC522_Auth(uint8_t authMode, uint8_t BlockAddr, uint8_t *Sectorkey,
		uint8_t *serNum)
{
	uint8_t status;
	uint16_t recvBits;
	uint8_t i;
	uint8_t buff[12];

	// Préparation des données d'authentification
	buff[0] = authMode; // Mode d'authentification (A ou B)
	buff[1] = BlockAddr; // Adresse du bloc

	// Copie de la clé du secteur
	for (i = 0; i < 6; i++)
	{
		buff[i + 2] = Sectorkey[i];
	}

	// Copie de l'UID
	for (i = 0; i < 4; i++)
	{
		buff[i + 8] = serNum[i];
	}

	// Envoi de la commande d'authentification
	status = MFRC522_ToCard(PCD_AUTHENT, buff, 12, buff, &recvBits);

	// Vérification du statut d'authentification
	if ((status != MI_OK) || (!(MFRC522_ReadRegister(Status2Reg) & 0x08)))
	{
		status = MI_ERR;
	}

	return status;
}

// Lecture d'un bloc de données
uint8_t MFRC522_Read(uint8_t blockAddr, uint8_t *recvData)
{
	uint8_t status;
	uint16_t unLen;

	// Préparation de la commande de lecture
	recvData[0] = PICC_READ;
	recvData[1] = blockAddr;

	// Calcul du CRC
	MFRC522_CalculateCRC(recvData, 2, &recvData[2]);

	// Envoi de la commande
	status = MFRC522_ToCard(PCD_TRANSCEIVE, recvData, 4, recvData, &unLen);

	// Vérification de la réponse
	if ((status != MI_OK) || (unLen != 0x90))
	{
		status = MI_ERR;
	}

	return status;
}

// Écriture dans un bloc de données
uint8_t MFRC522_Write(uint8_t blockAddr, uint8_t *writeData)
{
	uint8_t status;
	uint16_t recvBits;
	uint8_t i;
	uint8_t buff[18];

	// Préparation de la commande d'écriture
	buff[0] = PICC_WRITE;
	buff[1] = blockAddr;

	// Calcul du CRC
	MFRC522_CalculateCRC(buff, 2, &buff[2]);

	// Envoi de la commande initiale
	status = MFRC522_ToCard(PCD_TRANSCEIVE, buff, 4, buff, &recvBits);

	// Vérification de l'ACK
	if ((status != MI_OK) || (recvBits != 4) || ((buff[0] & 0x0F) != 0x0A))
	{
		status = MI_ERR;
	}

	if (status == MI_OK)
	{
		// Copie des données à écrire
		for (i = 0; i < 16; i++)
		{
			buff[i] = writeData[i];
		}

		// Calcul du CRC pour les données
		MFRC522_CalculateCRC(buff, 16, &buff[16]);

		// Envoi des données
		status = MFRC522_ToCard(PCD_TRANSCEIVE, buff, 18, buff, &recvBits);

		// Vérification de l'ACK
		if ((status != MI_OK) || (recvBits != 4) || ((buff[0] & 0x0F) != 0x0A))
		{
			status = MI_ERR;
		}
	}

	return status;
}
// Calcul du CRC
void MFRC522_CalculateCRC(uint8_t *pIndata, uint8_t len, uint8_t *pOutData)
{
	uint8_t i, n;

	// Configuration du calcul CRC
	MFRC522_ClearBitMask(DivIrqReg, 0x04); // Effacer l'indicateur de fin de calcul
	MFRC522_SetBitMask(FIFOLevelReg, 0x80); // Vider la FIFO

	// Remplissage de la FIFO avec les données
	for (i = 0; i < len; i++)
	{
		MFRC522_WriteRegister(FIFODataReg, pIndata[i]);
	}

	// Lancement du calcul CRC
	MFRC522_WriteRegister(CommandReg, PCD_CALCCRC);

	// Attente de la fin du calcul
	i = 0xFF;
	do
	{
		n = MFRC522_ReadRegister(DivIrqReg);
		i--;
	} while ((i != 0) && !(n & 0x04)); // Attente du flag CRCIrq

	// Lecture du résultat CRC
	pOutData[0] = MFRC522_ReadRegister(CRCResultRegL); // LSB
	pOutData[1] = MFRC522_ReadRegister(CRCResultRegH); // MSB
}

// Obtention de l'UID sous forme de chaîne hexadécimale
char* MFRC522_GetUidString(void)
{
	uint8_t str[2];
	uint8_t serNum[5];
	uint8_t status;
	static char buffer[20]; // Buffer statique pour conserver la valeur

	// Réinitialisation du buffer
	memset(buffer, 0, sizeof(buffer));

	// Détection d'une carte
	status = MFRC522_Request(PICC_REQIDL, str);
	if (status != MI_OK)
	{
		strcpy(buffer, "ERR_REQ");
		return buffer;
	}

	// Lecture de l'UID
	status = MFRC522_Anticoll(serNum);
	if (status != MI_OK)
	{
		strcpy(buffer, "ERR_ANTI");
		return buffer;
	}

	// Formatage de l'UID en hexadécimal
	sprintf(buffer, "%02X%02X%02X%02X", serNum[0], serNum[1], serNum[2],
			serNum[3]);

	return buffer;
}

// Vérification rapide de la présence d'une carte
uint8_t MFRC522_IsNewCardPresent(void)
{
	uint8_t buffer[2];
	return (MFRC522_Request(PICC_REQIDL, buffer) == MI_OK);
}

// Lecture robuste de l'UID
uint8_t MFRC522_ReadUid(MFRC522_Uid *uid)
{
	if (MFRC522_Anticoll(uid->uidByte) != MI_OK)
		return 0;

	uid->size = 4;
	uint8_t check = 0;
	for (uint8_t i = 0; i < 4; i++)
		check ^= uid->uidByte[i];

	return (check == uid->uidByte[4]) ? 1 : 0;
}
////////////////////////////////////////////////////////////////////////

void RFID_Access_Control(const uint8_t authorized_uids[][4],
		uint8_t num_authorized_uids)
{
	MFRC522_Uid uid;
	char uid_str[20];
	if (MFRC522_IsNewCardPresent() && MFRC522_ReadUid(&uid))
	{
		uint8_t authorized = 0;

		// Vérifier si l'UID est dans la liste blanche
		for (int i = 0; i < num_authorized_uids; i++)
		{
			if (memcmp(uid.uidByte, authorized_uids[i], 4) == 0)
			{
				authorized = 1;
				break;
			}
		}

		if (authorized)
		{
			UART_Print("Accès autorisé! ");
			// 5. Traiter l'UID (ex: affichage sur UART
			sprintf(uid_str, "UID : %02X%02X%02X%02X\r\n", uid.uidByte[0],
					uid.uidByte[1], uid.uidByte[2], uid.uidByte[3]);
			UART_Print(uid_str);
			// Action: allumer LED verte, ouvrir porte, etc.
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, RESET);
		}
		else
		{
			UART_Print("Accès refusé! ");
			// 5. Traiter l'UID (ex: affichage sur UART
			sprintf(uid_str, "UID : %02X%02X%02X%02X\r\n", uid.uidByte[0],
					uid.uidByte[1], uid.uidByte[2], uid.uidByte[3]);
			UART_Print(uid_str);
			// Action: allumer LED rouge, sonner alarme, etc.
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, SET);
		}

		// Attendre que la carte soit retirée
		while (MFRC522_IsNewCardPresent())
		{
			HAL_Delay(50);
		}
	}
	HAL_Delay(60);
}
