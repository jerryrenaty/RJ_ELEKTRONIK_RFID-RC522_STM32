#ifndef MFRC522_H
#define MFRC522_H

#include "stm32f1xx_hal.h"
#include <string.h>

extern UART_HandleTypeDef huart1; // Handle UART pour les messages de debug

#define MAX_LEN 16 // Taille maximale des données pouvant être lues/écrites

// Codes de retour des fonctions
#define MI_OK              0 // Opération réussie
#define MI_NOTAGERR        1 // Aucune carte détectée
#define MI_ERR            2  // Erreur lors de la communication

// Commandes pour les cartes RFID (PICC - Proximity Integrated Circuit Card)
#define PICC_REQIDL      0x26 // Requête pour cartes en état idle
#define PICC_REQALL      0x52 // Requête pour toutes les cartes
#define PICC_ANTICOLL    0x93 // Commande anti-collision
#define PICC_SElECTTAG   0x93 // Commande de sélection de carte
#define PICC_AUTHENT1A   0x60 // Authentification avec clé A
#define PICC_AUTHENT1B   0x61 // Authentification avec clé B
#define PICC_READ        0x30 // Lecture de bloc
#define PICC_WRITE       0xA0 // Écriture de bloc
#define PICC_DECREMENT   0xC0 // Décrémentation
#define PICC_INCREMENT   0xC1 // Incrémentation
#define PICC_RESTORE     0xC2 // Restauration
#define PICC_TRANSFER    0xB0 // Transfert
#define PICC_HALT        0x50 // Mise en veille

// Commandes pour le lecteur MFRC522 (PCD - Proximity Coupling Device)
#define PCD_IDLE              0x00 // Mode inactif
#define PCD_AUTHENT          0x0E  // Authentification
#define PCD_TRANSCEIVE       0x0C  // Transmission et réception
#define PCD_RESETPHASE       0x0F  // Réinitialisation
#define PCD_CALCCRC          0x03  // Calcul CRC
#define RFCfgReg             0x26

// Registres du MFRC522
#define CommandReg           0x01 // Registre de commande
#define ComIEnReg           0x02  // Registre d'activation des interruptions
#define DivIEnReg           0x03  // Registre d'activation des interruptions du diviseur
#define ComIrqReg           0x04  // Registre des flags d'interruption
#define DivIrqReg           0x05  // Registre des flags d'interruption du diviseur
#define ErrorReg            0x06  // Registre d'erreur
#define Status1Reg          0x07  // Registre de statut 1
#define Status2Reg          0x08  // Registre de statut 2
#define FIFODataReg         0x09  // Registre de données FIFO
#define FIFOLevelReg        0x0A  // Registre de niveau FIFO
#define ControlReg          0x0C  // Registre de contrôle
#define BitFramingReg       0x0D  // Registre de cadrage des bits
#define ModeReg             0x11  // Registre de mode
#define TxControlReg        0x14  // Registre de contrôle de transmission
#define TxAutoReg           0x15  // Registre de contrôle automatique de transmission
#define CRCResultRegH       0x21  // Registre de résultat CRC (MSB)
#define CRCResultRegL       0x22  // Registre de résultat CRC (LSB)
#define TModeReg            0x2A  // Registre de mode timer
#define TPrescalerReg       0x2B  // Registre de prédiviseur timer
#define TReloadRegL         0x2C  // Registre de recharge timer (LSB)
#define TReloadRegH         0x2D  // Registre de recharge timer (MSB)

// Structure pour stocker les informations d'une carte RFID
typedef struct {
    uint8_t size;           // Taille de l'UID (4, 7 ou 10 octets)
    uint8_t uidByte[10];    // Buffer pour stocker l'UID
    uint8_t sak;            // Select Acknowledge - réponse de sélection
} MFRC522_Uid;

// Prototypes des fonctions
void MFRC522_Init(SPI_HandleTypeDef *hspi, GPIO_TypeDef *CS_GPIOx, uint16_t CS_GPIO_Pin, GPIO_TypeDef *RST_GPIOx, uint16_t RST_GPIO_Pin);
void MFRC522_Reset(void);
void MFRC522_WriteRegister(uint8_t reg, uint8_t value);
uint8_t MFRC522_ReadRegister(uint8_t reg);
void MFRC522_SetBitMask(uint8_t reg, uint8_t mask);
void MFRC522_ClearBitMask(uint8_t reg, uint8_t mask);
void MFRC522_AntennaOn(void);
void MFRC522_AntennaOff(void);
uint8_t MFRC522_Request(uint8_t reqMode, uint8_t *TagType);
uint8_t MFRC522_ToCard(uint8_t command, uint8_t *sendData, uint8_t sendLen, uint8_t *backData, uint16_t *backLen);
uint8_t MFRC522_Anticoll(uint8_t *serNum);
uint8_t MFRC522_Check(MFRC522_Uid *uid);
uint8_t MFRC522_SelectTag(uint8_t *serNum);
uint8_t MFRC522_Auth(uint8_t authMode, uint8_t BlockAddr, uint8_t *Sectorkey, uint8_t *serNum);
uint8_t MFRC522_Read(uint8_t blockAddr, uint8_t *recvData);
uint8_t MFRC522_Write(uint8_t blockAddr, uint8_t *writeData);
void MFRC522_CalculateCRC(uint8_t *pIndata, uint8_t len, uint8_t *pOutData);
char* MFRC522_GetUidString(void);
uint8_t MFRC522_IsNewCardPresent(void);
uint8_t MFRC522_ReadUid(MFRC522_Uid *uid);
///////////////////////////////////////////////////////
void RFID_Access_Control(const uint8_t authorized_uids[][4], uint8_t num_authorized_uids);

#endif // MFRC522_H
